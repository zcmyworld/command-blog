import ITOS from '@/ITOS';


export default {
  exec(route_path) {
    // console.log(ITOS.Router)
    ITOS.Router.router.push('/article/1/edit');
  }
}
