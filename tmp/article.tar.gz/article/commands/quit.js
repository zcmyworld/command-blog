import ITOS from '@/ITOS';


export default {
  exec(route_path) {
    ITOS.Router.router.push('/article');
  }
}
