import ITOS from '@/ITOS';

export default {
  exec() {
    ITOS.Terminal.print('save success ..');
  }
}
